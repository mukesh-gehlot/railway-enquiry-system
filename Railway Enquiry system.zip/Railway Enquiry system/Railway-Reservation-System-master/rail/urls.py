"""rail URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
import home
import features
from home import views
from features import views

app_name = 'basic'
urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home.views.log, name='log'),
    path('register/', home.views.Reg, name="reg"),

    # path('logout/',views.logout,name="logout"),
    # path('home/',include('home.urls',namespace="home"),name="home"),

    path('home/', home.views.home, name="home1"),
    path('logout/', home.views.logout),
    path('search/', features.views.search, name="search"),
    path('search/trains', features.views.getTrains),
    path('schedule/', features.views.schedule, name="schedule"),
    path('schedule/trains', features.views.getTinfo),
    path('addR/', features.views.addR, name="addR"),
    path('addST/', features.views.addST),
    path('addT/', features.views.addT),
    path('addRT/', features.views.addRT),
    path('search/search/trains/cva/', features.views.cva),
    path('search/book1/', features.views.book1),
    path('search/book1/book/', features.views.book),
    path('cancel/', features.views.cancel, name="cancel"),
    path('cancel/cancel/cn/', features.views.cn),
    path('pnr/', features.views.pnr, name="pnr"),

]
