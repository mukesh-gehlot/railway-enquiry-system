from django.urls import path
from django.contrib import admin

from features import views

